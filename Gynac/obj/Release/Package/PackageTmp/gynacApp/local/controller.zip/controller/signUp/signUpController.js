app.controller("signUpController",["$scope", "dataService", "$rootScope", "$state", function($scope, dataService, $rootScope, $state){
	
    $scope.emailVerified = function () {
        var webURL = 'api/gynac/emailVerified';
        console.log($scope.user);
        dataService.postData(webURL, $scope.user).then(function (data) {
            console.log(data)
            $scope.submitData();
        }, function (errorMessage) {
            console.log(errorMessage + ' Error......');
        });
    }

	$scope.submitData = function(){
	    var webURL = 'api/gynac/saveuser';
		console.log($scope.user);
		dataService.postData(webURL, $scope.user).then(function (data) {
			console.log(data);
            if(data == 'Found'){
                $('#triggerFoundSignupModal').trigger('click');
            }else{               
                $('#triggerSucsessfullySignupModal').trigger('click');
            }
            //$state.go('home');
		}, function (errorMessage) {
			console.log(errorMessage + ' Error......');
		});
	}
    
    $scope.signOut = function(){
        $rootScope.authenticatedUser = {};
        $rootScope.authenticatedUser.UserInfo = {};
        $state.go('home');
    }
    
    $scope.goToHome = function(){
        $state.go('home');
    }
	
}]);