app.controller("trainingController",["$scope", "dataService", "$rootScope", "$state", function($scope, dataService, $rootScope, $state){
	
    if(!$rootScope.authenticatedUser.UserInfo.User_Id){
        $state.go('home');
    }
    
	$scope.clickMe = function(){
		var webURL = 'appData/zoneData.json'
		dataService.getData(webURL).then(function (data) {
			console.log(data)
		}, function (errorMessage) {
			console.log(errorMessage + ' Error......');
		});
	}
    
    $scope.signOut = function(){
        $rootScope.authenticatedUser = {};
        $rootScope.authenticatedUser.UserInfo = {};
        $state.go('home');
    }
	
}]);