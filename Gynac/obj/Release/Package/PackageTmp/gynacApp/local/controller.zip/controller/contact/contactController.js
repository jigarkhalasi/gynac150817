app.controller("contactController",["$scope", "dataService", "$rootScope", "$state", function($scope, dataService, $rootScope, $state){
	
    $scope.contactUs = function () {
        var webURL = 'api/gynac/sendcontactusemail'
		dataService.postData(webURL, $scope.contact).then(function (data) {
		    console.log(data);
		    $("#triggerMailSentModal").trigger('click');
		}, function (errorMessage) {
			console.log(errorMessage + ' Error......');
		});
	}
    
    $scope.signOut = function(){
        $rootScope.authenticatedUser = {};
        $rootScope.authenticatedUser.UserInfo = {};
        $state.go('home');
    }

    $scope.goToHome = function () {
        $state.go('home');
    }
	
}]);