app.controller("myProfileController",["$scope", "dataService", "$rootScope", "$state", function($scope, dataService, $rootScope, $state){
	
	$scope.clickMe = function(){
		var webURL = 'appData/zoneData.json'
		dataService.getData(webURL).then(function (data) {
			console.log(data)
		}, function (errorMessage) {
			console.log(errorMessage + ' Error......');
		});
	}
    
    if(!$rootScope.authenticatedUser.UserInfo.User_Id){
        $state.go('home');
    }
    
    $scope.profile = true;
    
    $scope.editProfile = function(){
        $scope.profile = false;
        $scope.user = angular.copy($rootScope.authenticatedUser.UserInfo);
    }
    
    $scope.submitData = function(){
        var webURL = 'api/gynac/updateuser';
		console.log($scope.user);
		dataService.postData(webURL, $scope.user).then(function (data) {
			console.log(data);
			$rootScope.authenticatedUser = data;

            $state.go('home');
		}, function (errorMessage) {
			console.log(errorMessage + ' Error......');
		});
	}
    
    $scope.signOut = function(){
        $rootScope.authenticatedUser = {};
        $rootScope.authenticatedUser.UserInfo = {};
        $state.go('home');
    }
}]);