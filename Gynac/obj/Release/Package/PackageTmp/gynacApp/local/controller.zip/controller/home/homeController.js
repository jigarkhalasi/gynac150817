app.controller("homeController",["$scope", "$rootScope", "dataService", "$state", "$stateParams", function($scope, $rootScope, dataService, $state, $stateParams){
	
    $scope.openPreviewVideo = function(src){
        $('#previewVideo').attr('src',src);
        $('#previewVideo').get(0).play();
        $scope.previewSrc = src;
    }
    
    $(document).ready(function(){
        $(window).resize(function(){
            setBlockHeight();
        });
        
        function setBlockHeight(){
            $('#b1').height($('#b2').height());
            $('#b3').height($('#b4').height());
        }
        
        setInterval(function(){
            setBlockHeight();
        },10)
        
    });
    
    $scope.signOut = function(){
        $rootScope.authenticatedUser = {};
        $rootScope.authenticatedUser.UserInfo = {};
        $state.go('home');
    }
    
    $scope.verifyEmail = function(){
        var webURL = 'api/gynac/emailverified'
        var dataToBeSend = {};
        dataToBeSend.Guid = $stateParams.id;
        dataToBeSend.Email = $stateParams.email;
        console.log(dataToBeSend);
		dataService.postData(webURL, dataToBeSend).then(function (data) {
			console.log(data);
            $('#triggerSucsessfullyVerifyEmailModal').trigger('click');
		}, function (errorMessage) {
			console.log(errorMessage + ' Error......');
		});
	}
    
    if($state.is('emailVerification')){
        $scope.verifyEmail();
    }
    
}]);