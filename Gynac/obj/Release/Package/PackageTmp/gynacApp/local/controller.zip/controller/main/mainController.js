app.controller('mainCtrl', function($scope, $rootScope, $state) {
    $rootScope.speakerVideoList = [
        {
            title : 'Torsion: A Diagnostic Dilemma Made Easy',
            des1 : 'This talk will cover the importance of timely diagnosis and diagnostic features of       torsion. In addition to the common but not specific features,',
            des2 : 'it will also cover three specific features of torsion that are simple and yet significantly enhance the diagnostic accuracy of ultrasound in torsion. Torsion of other adnexal structures is also briefly discussed. Evidence based management of torsion is also touched upon with specific emphasis on conservation of torsed ovaries.',
            iconSrc:'gynacApp/local/img/torsion/icon.png',
            profilePicSrc : 'gynacApp/local/img/profile1.png',
            previewSrc : 'gynacApp/local/img/torsion/video/Slide 12.mp4',
            audioSrc : 'gynacApp/local/media/Session 02.mp3',
            amount : 2500,
            Course_Id : 1,
            DrName : 'Dr. Mala Sibal',
            videoList : [
                {
                    timing : '07:21',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 12.mp4',
                    posX : '9.4%',
                    posY : '51%',
                    width : '92%',
                    fullViewPosX : '20%',
                    fullViewPosY : '53%',
                    fullVieWidth : '100%'
                },
                {
                    timing : '11:05',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 17_1.mp4',
                    posX : '9.4%',
                    posY : '51%',
                    width : '92%',
                    fullViewPosX : '20%',
                    fullViewPosY : '53%',
                    fullVieWidth : '100%'
                },
                {
                    timing : '11:42',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 17_2.mp4',
                    posX : '48%',
                    posY : '55%',
                    width : '100%',
                    fullViewPosX : '51%',
                    fullViewPosY : '51%',
                    fullVieWidth : '110%'
                },
                {
                    timing : '15:00',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 22.mp4',
                    posX : '43%',
                    posY : '41%',
                    width : '100%',
                    fullViewPosX : '50%',
                    fullViewPosY : '51%',
                    fullVieWidth : '110%'
                },
                {
                    timing : '17:45',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 25.mp4',
                    posX : '47%',
                    posY : '55%',
                    width : '100%',
                    fullViewPosX : '46%',
                    fullViewPosY : '53%',
                    fullVieWidth : '100%'
                },
                {
                    timing : '18:58',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 26.mp4',
                    posX : '44%',
                    posY : '25%',
                    width : '109%',
                    fullViewPosX : '44%',
                    fullViewPosY : '26%',
                    fullVieWidth : '115%'
                },
                {
                    timing : '20:51',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 27_1.mp4',
                    posX : '48%',
                    posY : '55%',
                    width : '100%'
                },
                {
                    timing : '21:43',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 27_2.mp4',
                    posX : '48%',
                    posY : '55%',
                    width : '100%',
                    fullViewPosX : '20%',
                    fullViewPosY : '53%',
                    fullVieWidth : '100%'
                },
                {
                    timing : '22:52',
                    videoSrc : 'gynacApp/local/img/torsion/video/Slide 27_3.mp4',
                    posX : '48%',
                    posY : '55%',
                    width : '100%',
                    fullViewPosX : '20%',
                    fullViewPosY : '53%',
                    fullVieWidth : '100%'
                }
            ],
            audioTiming : [
                '00:00',
                '00:37',
                '00:53',
                '01:05',
                '01:16',
                '01:27',
                '01:36',
                '01:42',
                '01:54',
                '01:58',
                '02:14',
                '02:32',
                '02:35',
                '02:40',
                '03:52',
                '03:59',
                '04:06',
                '04:23',
                '04:38',
                '04:42',
                '04:48',
                '04:53',
                '04:55',
                '04:58',
                '05:06',
                '05:13',
                '05:18',
                '05:22',
                '05:30',
                '05:38',
                '05:43',
                '05:56',
                '06:07',
                '06:12',
                '06:21',
                '06:28',
                '06:33',
                '06:44',
                '07:02',
                '07:11',
                '07:17',
                //'07:21',
                '07:49',
                '08:44',
                '08:59',
                '09:02',
                '09:05',
                '09:08',
                '09:10',
                '09:35',
                '09:42',
                '09:43',
                '09:46',
                '09:54',
                '09:58',
                '10:03',
                '10:12',
                '10:24',
                '10:34',
                '10:41',
                '10:45',
                '11:03',
                //'11:05',
                '11:38',
                //'11:42',
                '12:05',
                '12:08',
                '12:17',
                '12:21',
                '12:35',
                '12:51',
                '12:55',
                '12:59',
                '13:06',
                '13:35',
                '13:37',
                '13:41',
                '13:45',
                '13:49',
                '13:53',
                '14:12',
                '14:16',
                '14:17',
                '14:29',
                //'15:00',
                '15:39',
                '15:44',
                '15:49',
                '15:57',
                '16:22',
                '16:24',
                '16:29',
                '16:31',
                '16:39',
                '16:41',
                '16:49',
                '17:03',
                '17:16',
                '17:29',
                '17:36',
                //'17:45',
                '18:00',
                '18:04',
                '18:32',
                '18:46',
                '18:50',
                '18:54',
                '18:56',
                //'18:58',
                '19:19',
                '19:24',
                '20:33',
                //'20:51',
                '21:36',
                //'21:43',
                '22:37',
                //'22:52',
                '23:16',
                '23:27',
                '23:48',
                '24:03',
                '24:35',
                '24:44',
                '25:30',
                '25:45',
                '25:50',
                '26:04',
                '26:15',
                '26:32'
            ]
        },
        {
            title : 'Scanning the Pelvis: Basics Along with Tips and Tricks',
            des1 : 'This lecture is especially useful for beginners in ultrasound as basic methodology and manoeuvres is discussed. A few tips and tricks that enhance ultrasound diagnosis have been highlighted.',
            des2 : 'The usefulness of 3D ultrasound and Doppler are briefly touched upon.  Reporting of a basic pelvic scan is also dealt with.',
            iconSrc : 'gynacApp/local/img/Scanning_the_Pelvis/icon.png',
            profilePicSrc : 'gynacApp/local/img/profile1.png',
            previewSrc : '',
            audioSrc : '',
            amount : 2500,
            Course_Id : 2,
            DrName : 'Dr. Mala Sibal',
            videoList : [
                
            ],
            audioTiming : [
                
            ]
            
        },
        {
            title : 'Congenital Uterine Anomalies - Simplified  ',
            des1 : 'The lecture aims to simplify diagnosis of uterine anomalies which can be confusing because of various classifications in place and various ultrasound diagnostic criteria for each anomaly.',
            des2 : 'The talk touches upon embryology and how to diagnose the type of uterine anomaly, based on two simple ultrasound abnormalities; that of the serosal contour of the uterine fundus and shape of the uterine cavity. Ultrasound reporting of these abnormalities is also discussed.',
            iconSrc : 'gynacApp/local/img/Congenital_Uteri_e Anomalies/icon.png',
            profilePicSrc : 'gynacApp/local/img/profile1.png',
            previewSrc : '',
            audioSrc : '',
            amount : 2500,
            Course_Id : 3,
            DrName : 'Dr. Mala Sibal',
            videoList : [
                
            ],
            audioTiming : [
                
            ]
        },
        {
            title : 'Spectrum of Endometriosis: Beyond ‘Ground Glass’ Endometriotic Cysts',
            des1 : 'The ultrasound features of the spectrum of endometriosis is covered; which includes ovarian endometriotic cysts, deep infiltrating endometriosis of the pelvis and extra pelvic endometriosis (including abdominal wall endometriosis.',
            des2 : 'In each category ultrasound features of each location have been illustrated. Site specific diagnosis of endometriosis is essential for management (especially at surgery) and is an expectation today from a transvaginal ultrasound, by the referring clinician. This talk will help achieve that end.',
            iconSrc : 'gynacApp/local/img/Spectrum_of_Endometriosis/icon.png',
            profilePicSrc : 'gynacApp/local/img/profile1.png',
            previewSrc : '',
            audioSrc : '',
            amount : 2500,
            Course_Id : 4,
            DrName : 'Dr. Mala Sibal',
            videoList : [
                
            ],
            audioTiming : [
                
            ]
        }
    ];
    
    // User Obj
    
    $rootScope.authenticatedUser = {};
    $rootScope.authenticatedUser.UserInfo = {};
    
    $scope.signOut = function(){
        $rootScope.authenticatedUser = {};
        $rootScope.authenticatedUser.UserInfo = {};
        $state.go('home');
    }
    
    /*$(document).on("contextmenu",function(){
       return false;
    });
*/
});
